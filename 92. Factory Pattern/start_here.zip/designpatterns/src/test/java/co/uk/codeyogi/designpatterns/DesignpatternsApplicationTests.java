package co.uk.codeyogi.designpatterns;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DesignpatternsApplicationTests {

	@Test
	void contextLoads() {
	}

}
