package co.uk.codeyogi.strategy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StrategyApplicationTests {

	@Test
	void contextLoads() {
	}

}
